# ALSAS AGRO TECH — Android MVP source (v0.9.7)

**Company:** ALSAS AGRO FOODS AND CHEMICALS NG ENTERPRISES  
**Product:** ALSAS AGRO TECH  
**Tagline:** Your Farm. Your Records. Your Profit.  
**Founder:** Salahuddeen Ibrahim Abubakar

## Purpose of this build
This is an offline-first Android MVP for an initial controlled test with farmers. It is not yet the complete commercial platform and is not ready for public Play Store release until the build, device tests, security review, and remaining integrations are completed.

## Included in this source
- Kotlin, Jetpack Compose, Room database, and local persistence.
- Local farmer profile: name, phone, state, LGA, village, language.
- Multiple farm records: farm name, crop, area in hectares, season, state/LGA/village, location note, variety.
- Farm activity planner: title, due date, note, completion status.
- Farm finance ledger: income and expenses by farm, category and date; money stored as integer Kobo.
- Harvest records: crop, date, kilograms, bags, bag weight, losses, optional sale price.
- Soil test records: pH, N/P/K, organic matter, texture, laboratory and notes.
- Offline calculators for fertilizer product quantity, seed quantity, spray product amount, and spray-water volume. They require user-entered agronomy/label rates and do not invent application rates.
- Farm summary: recorded income, expenses, profit/loss, harvest, losses, yield per hectare and clearly labelled estimated bag-sale value.
- CSV and one-page PDF report export using Android's Storage Access Framework.
- Hausa-first interface labels with English terminology where useful.

## Data and accounting rules
- Financial values are stored as integer Kobo. Input accepts values such as `1000`, `1,000`, `1,250.75`, and `250,50`; invalid or over-precision amounts are rejected.
- Profit/loss = recorded ledger income minus recorded ledger expenses. Estimated harvest value is displayed separately and is not counted as confirmed income.
- Harvest and soil-test values are farmer-entered records, not independently verified measurements.
- Deleting a farm removes that farm's ledger, tasks, harvest and soil-test records in one Room transaction. This is destructive for that farm; test with disposable records first.
- Room migrations v1→v8 are provided. Do not enable destructive migration or remove migration steps when real farmer data exists.
- Farm location is manually entered. GPS boundary mapping is not implemented.

## Deliberately not live / not included yet
- No online sign-up, OTP, password authentication, user accounts or cloud sync.
- No backend server, PostgreSQL, admin portal, or multi-device access.
- Suppliers and Marketplace screens are informational placeholders; no verified catalog, inventory, order, payment, buyer/seller messaging or logistics are live.
- Farmer Academy currently shows topic placeholders; no actual video library, offline lesson downloads, quizzes or subscription gate.
- No live weather, satellite data, AI image diagnosis, pest recognition, or crop-specific fertilizer prescription.
- No Android reminder notifications or recurring calendar events.
- No premium billing, ads, payment gateway, export-market integration or production analytics.
- PDF export is a concise one-page summary, not a full multi-page accounting statement.

## Project versions
- Android `versionName`: `0.9.7`
- Android `versionCode`: `17`
- Room database version: `8`
- Application ID: `com.alsas.agrotech`
- Minimum Android: API 26 (Android 8.0)
- Compile/target SDK: 35

## Verification completed in this environment
Run from the project root:

```bash
python tools/verify_migrations.py
```

This SQLite regression script mirrors the migration SQL path v1→v8 and checks Naira-to-Kobo conversion, legacy row preservation, new farm columns, harvest/soil tables, indexes, and SQLite integrity. It is not a Room migration test and does not execute the app.

The pure Kotlin utility sources (`Money`, `CsvReport`, `SoilInterpreter`, `InputCalculator`) were compiled with the available Kotlin compiler. Android/Compose source was reviewed and corrected, but a full Gradle/Android build has **not** been run in this environment because Android SDK and Gradle are unavailable here.

## Build and test in Android Studio
1. Install a recent stable Android Studio and Android SDK Platform 35.
2. Open this project folder (the folder containing `settings.gradle.kts`).
3. Allow Gradle to sync and download dependencies. The project uses Android Gradle Plugin 8.7.3, Kotlin 2.0.21, Compose BOM 2024.12.01, Room 2.6.1 and KSP 2.0.21-1.0.28.
4. Run `python tools/verify_migrations.py` from the project root. The GitHub Actions workflow also runs this migration regression check before the Android unit tests.
5. Run `gradle --no-daemon :app:testDebugUnitTest` or use the Gradle tool window in Android Studio.
6. Run `gradle --no-daemon :app:assembleDebug` or use Build > Build Bundle(s) / APK(s) > Build APK(s).
7. Install the debug APK on a test phone/emulator (Android 8.0 or newer) and complete the checklist below.

There is no Gradle wrapper included in this package. The GitHub Actions workflow installs Gradle 8.9 directly. For local command-line builds, install Gradle 8.9 or generate and commit a Gradle 8.9 wrapper from Android Studio.

## First device-test checklist
Use test/demo data only. Do not import valuable farmer records until backup/export and migration behavior have been reviewed.

- [ ] App installs, launches and survives close/reopen.
- [ ] Save, edit and reopen a farmer profile.
- [ ] Create two farms; select each; edit one and verify the other is unchanged.
- [ ] Add income and expense to each farm; verify totals and profit/loss independently.
- [ ] Test amount inputs: `1000`, `1,000`, `1,250.75`, `250,50`, `10.001`, `0`, negative and very large values.
- [ ] Add, complete and reopen farm tasks; test invalid dates such as `2026-02-30` and trailing text.
- [ ] Add harvest records; verify kilograms, bags, losses and yield/ha.
- [ ] Add soil test values including invalid pH, negative nutrients and organic matter above 100%.
- [ ] Run each calculator with known test inputs and compare the arithmetic manually.
- [ ] Export CSV and PDF to device storage; open both in other apps and inspect contents/encoding.
- [ ] Delete a disposable farm and verify its ledger, tasks, harvest and soil tests are removed; verify other farms are untouched.
- [ ] Upgrade a disposable database through migration versions and verify all older records remain.
- [ ] Rotate screen, background/restore app, and test on a smaller phone screen.

## Release gate
Do not distribute publicly or use for critical financial decisions until Android Studio build succeeds, unit and Room instrumentation tests pass, the device checklist is completed, data backup/recovery is designed, security/privacy notices are added, and all live-service claims are either implemented or removed from the UI.

## Automated Android build (GitHub Actions)
A GitHub Actions workflow is included at `.github/workflows/android-build.yml`. After pushing this project to a GitHub repository, use the **Actions** tab and run **ALSAS AGRO TECH Android verification**. It provisions JDK 17, Gradle 8.9 and Android SDK Platform 35, runs JVM unit tests, builds the debug APK, and uploads the APK as a workflow artifact. This workflow has been added to source but has **not** been executed from this environment; a successful run is still required to confirm the full Android build.
