"""SQLite regression test mirroring Room migrations v1 -> v8.
Run: python tools/verify_migrations.py
This is not a substitute for Room schema validation or Android instrumentation tests.
"""
import sqlite3


def run():
    db = sqlite3.connect(":memory:")
    db.execute("PRAGMA foreign_keys=ON")
    db.executescript("""
        CREATE TABLE farm_records (
            id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
            farmName TEXT NOT NULL, crop TEXT NOT NULL, hectares REAL NOT NULL,
            season TEXT NOT NULL, createdAt INTEGER NOT NULL
        );
        CREATE TABLE ledger (
            id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
            farmId INTEGER NOT NULL, title TEXT NOT NULL, amountNaira REAL NOT NULL,
            kind TEXT NOT NULL, category TEXT NOT NULL, dateMillis INTEGER NOT NULL,
            note TEXT NOT NULL
        );
        CREATE TABLE farm_tasks (
            id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, farmId INTEGER NOT NULL,
            title TEXT NOT NULL, dueDateMillis INTEGER NOT NULL,
            completed INTEGER NOT NULL, note TEXT NOT NULL
        );
        INSERT INTO farm_records VALUES (1, 'Gonar Gwaji', 'Masara', 2.5, 'Damina', 1000);
        INSERT INTO ledger VALUES (1, 1, 'Takin NPK', 1250.75, 'EXPENSE', 'Taki', 1100, 'legacy');
        INSERT INTO ledger VALUES (2, 999, 'Legacy orphan', 25.00, 'INCOME', 'Sayarwa', 1200, 'orphan row');
        INSERT INTO farm_tasks VALUES (1, 1, 'Shuka', 1300, 0, '');
        INSERT INTO farm_tasks VALUES (2, 999, 'Legacy task', 1400, 1, 'orphan task');
    """)

    # v1 -> v2: convert Naira REAL to Kobo INTEGER.
    db.executescript("""
        CREATE TABLE ledger_new (
            id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, farmId INTEGER NOT NULL,
            title TEXT NOT NULL, amountKobo INTEGER NOT NULL, kind TEXT NOT NULL,
            category TEXT NOT NULL, dateMillis INTEGER NOT NULL, note TEXT NOT NULL
        );
        INSERT INTO ledger_new SELECT id, farmId, title, CAST(ROUND(amountNaira * 100) AS INTEGER),
            kind, category, dateMillis, note FROM ledger;
        DROP TABLE ledger; ALTER TABLE ledger_new RENAME TO ledger;
        CREATE INDEX index_ledger_farmId ON ledger(farmId);
        CREATE INDEX index_ledger_dateMillis ON ledger(dateMillis);
        CREATE INDEX index_farm_tasks_farmId ON farm_tasks(farmId);
        CREATE INDEX index_farm_tasks_dueDateMillis ON farm_tasks(dueDateMillis);
    """)

    # v2 -> v3: rebuild tasks, retaining all rows.
    db.executescript("""
        CREATE TABLE farm_tasks_new (
            id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, farmId INTEGER NOT NULL,
            title TEXT NOT NULL, dueDateMillis INTEGER NOT NULL, completed INTEGER NOT NULL, note TEXT NOT NULL
        );
        INSERT INTO farm_tasks_new SELECT id, farmId, title, dueDateMillis, completed, note FROM farm_tasks;
        DROP TABLE farm_tasks; ALTER TABLE farm_tasks_new RENAME TO farm_tasks;
        CREATE INDEX index_farm_tasks_farmId ON farm_tasks(farmId);
        CREATE INDEX index_farm_tasks_dueDateMillis ON farm_tasks(dueDateMillis);
    """)

    # v3 -> v4: remove prototype FK constraints, preserving orphan rows.
    db.executescript("""
        CREATE TABLE ledger_v4 (
            id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, farmId INTEGER NOT NULL,
            title TEXT NOT NULL, amountKobo INTEGER NOT NULL, kind TEXT NOT NULL,
            category TEXT NOT NULL, dateMillis INTEGER NOT NULL, note TEXT NOT NULL
        );
        INSERT INTO ledger_v4 SELECT id, farmId, title, amountKobo, kind, category, dateMillis, note FROM ledger;
        DROP TABLE ledger; ALTER TABLE ledger_v4 RENAME TO ledger;
        CREATE INDEX index_ledger_farmId ON ledger(farmId);
        CREATE INDEX index_ledger_dateMillis ON ledger(dateMillis);
        CREATE TABLE farm_tasks_v4 (
            id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, farmId INTEGER NOT NULL,
            title TEXT NOT NULL, dueDateMillis INTEGER NOT NULL, completed INTEGER NOT NULL, note TEXT NOT NULL
        );
        INSERT INTO farm_tasks_v4 SELECT id, farmId, title, dueDateMillis, completed, note FROM farm_tasks;
        DROP TABLE farm_tasks; ALTER TABLE farm_tasks_v4 RENAME TO farm_tasks;
        CREATE INDEX index_farm_tasks_farmId ON farm_tasks(farmId);
        CREATE INDEX index_farm_tasks_dueDateMillis ON farm_tasks(dueDateMillis);
    """)

    # v4 -> v5: local farmer profile.
    db.execute("""CREATE TABLE farmer_profile (
        id INTEGER NOT NULL PRIMARY KEY, fullName TEXT NOT NULL, phone TEXT NOT NULL,
        state TEXT NOT NULL, localGovernment TEXT NOT NULL, village TEXT NOT NULL,
        preferredLanguage TEXT NOT NULL, updatedAt INTEGER NOT NULL)""")
    db.execute("INSERT INTO farmer_profile VALUES (1,'Gwajin Manomi','08012345678','Kaduna','Lere','Saminaka','Hausa',1500)")

    # v5 -> v6: farm location/variety/date columns. Defaults are part of Room schema.
    db.executescript("""
        ALTER TABLE farm_records ADD COLUMN state TEXT NOT NULL DEFAULT '';
        ALTER TABLE farm_records ADD COLUMN localGovernment TEXT NOT NULL DEFAULT '';
        ALTER TABLE farm_records ADD COLUMN village TEXT NOT NULL DEFAULT '';
        ALTER TABLE farm_records ADD COLUMN locationNote TEXT NOT NULL DEFAULT '';
        ALTER TABLE farm_records ADD COLUMN variety TEXT NOT NULL DEFAULT '';
        ALTER TABLE farm_records ADD COLUMN plantingDateMillis INTEGER;
        ALTER TABLE farm_records ADD COLUMN expectedHarvestMillis INTEGER;
    """)

    # v6 -> v7: harvest records.
    db.executescript("""
        CREATE TABLE harvest_records (
            id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, farmId INTEGER NOT NULL,
            cropName TEXT NOT NULL, harvestDateMillis INTEGER NOT NULL, quantityKg REAL NOT NULL,
            bagsCount REAL NOT NULL, bagWeightKg REAL NOT NULL, lossKg REAL NOT NULL,
            salePricePerBagKobo INTEGER NOT NULL, notes TEXT NOT NULL);
        CREATE INDEX index_harvest_records_farmId ON harvest_records(farmId);
        CREATE INDEX index_harvest_records_harvestDateMillis ON harvest_records(harvestDateMillis);
    """)

    # v7 -> v8: soil test records.
    db.executescript("""
        CREATE TABLE soil_tests (
            id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, farmId INTEGER NOT NULL,
            testDateMillis INTEGER NOT NULL, ph REAL, nitrogenMgKg REAL, phosphorusMgKg REAL,
            potassiumMgKg REAL, organicMatterPercent REAL, texture TEXT NOT NULL,
            laboratory TEXT NOT NULL, notes TEXT NOT NULL);
        CREATE INDEX index_soil_tests_farmId ON soil_tests(farmId);
        CREATE INDEX index_soil_tests_testDateMillis ON soil_tests(testDateMillis);
    """)

    assert db.execute("SELECT amountKobo FROM ledger WHERE id=1").fetchone()[0] == 125075
    assert db.execute("SELECT COUNT(*) FROM ledger").fetchone()[0] == 2
    assert db.execute("SELECT COUNT(*) FROM farm_tasks").fetchone()[0] == 2
    assert db.execute("SELECT farmId FROM ledger WHERE id=2").fetchone()[0] == 999
    assert db.execute("SELECT farmId FROM farm_tasks WHERE id=2").fetchone()[0] == 999
    assert db.execute("SELECT state, localGovernment, village FROM farm_records WHERE id=1").fetchone() == ('', '', '')
    assert db.execute("SELECT COUNT(*) FROM harvest_records").fetchone()[0] == 0
    assert db.execute("SELECT COUNT(*) FROM soil_tests").fetchone()[0] == 0
    assert db.execute("PRAGMA foreign_key_list(ledger)").fetchall() == []
    assert db.execute("PRAGMA foreign_key_list(farm_tasks)").fetchall() == []
    assert db.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
    print("PASS: Room SQL migration path v1->v8, Kobo conversion, legacy row preservation, farm defaults, harvest/soil tables, indexes and SQLite integrity")


if __name__ == "__main__":
    run()
