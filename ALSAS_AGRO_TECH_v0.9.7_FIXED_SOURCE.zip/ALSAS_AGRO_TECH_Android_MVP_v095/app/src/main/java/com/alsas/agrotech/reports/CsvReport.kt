package com.alsas.agrotech.reports

/** CSV helpers for farmer reports. UTF-8 output; spreadsheet formula injection is neutralized. */
object CsvReport {
    fun row(vararg values: String): String = values.joinToString(",") { escape(it) }

    fun document(rows: List<List<String>>): String =
        rows.joinToString("\r\n") { row(*it.toTypedArray()) } + "\r\n"

    private fun escape(value: String): String {
        // Spreadsheet applications may ignore leading whitespace/control characters before formulas.
        val firstMeaningful = value.firstOrNull { !it.isWhitespace() && it != '\uFEFF' }
        val safe = if (firstMeaningful in listOf('=', '+', '-', '@')) "'" + value else value
        return "\"${safe.replace("\"", "\"\"")}\""
    }
}
