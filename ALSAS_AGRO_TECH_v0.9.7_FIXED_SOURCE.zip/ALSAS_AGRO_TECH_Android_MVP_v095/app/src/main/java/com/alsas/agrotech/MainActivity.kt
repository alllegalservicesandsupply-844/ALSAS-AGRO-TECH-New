package com.alsas.agrotech

import android.os.Bundle
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.platform.LocalContext
import com.alsas.agrotech.reports.CsvReport
import java.io.ByteArrayOutputStream
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.alsas.agrotech.data.FarmDatabase
import com.alsas.agrotech.data.FarmRecord
import com.alsas.agrotech.data.LedgerEntry
import com.alsas.agrotech.data.FarmTask
import com.alsas.agrotech.data.FarmerProfile
import com.alsas.agrotech.data.HarvestRecord
import com.alsas.agrotech.data.SoilTestRecord
import com.alsas.agrotech.soil.SoilInterpreter
import com.alsas.agrotech.util.parseNairaToKobo
import com.alsas.agrotech.calculators.InputCalculator
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.flowOf
import java.text.NumberFormat
import java.util.Locale
import java.text.SimpleDateFormat
import java.text.ParsePosition
import java.util.Date
import java.util.TimeZone

private val AlsasGreen = Color(0xFF176B36)
private val AlsasPale = Color(0xFFEAF4E9)
private val naira = NumberFormat.getCurrencyInstance(Locale("en", "NG"))

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val database = FarmDatabase.get(applicationContext)
        setContent { AgroApp(database) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AgroApp(database: FarmDatabase) {
    val dao = database.farmDao()
    val context = LocalContext.current
    var exportBytes by remember { mutableStateOf<ByteArray?>(null) }
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("*/*")) { uri ->
        val bytes = exportBytes
        if (uri != null && bytes != null) runCatching {
            context.contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
        }
        exportBytes = null
    }
    val scope = rememberCoroutineScope()
    var tab by remember { mutableStateOf("Home") }
    val farmerProfile by dao.farmerProfile().collectAsState(initial = null)
    val farms by dao.farms().collectAsState(initial = emptyList())
    var selectedFarmId by remember { mutableLongStateOf(0L) }
    val selectedFarm = farms.firstOrNull { it.id == selectedFarmId } ?: farms.firstOrNull()
    LaunchedEffect(farms) {
        if (selectedFarmId == 0L && farms.isNotEmpty()) selectedFarmId = farms.first().id
    }
    val farmId = selectedFarm?.id ?: 0L
    val taskFlow = remember(farmId) { if (farmId > 0L) dao.tasks(farmId) else flowOf(emptyList()) }
    val farmTasks by taskFlow.collectAsState(initial = emptyList())
    val soilFlow = remember(farmId) { if (farmId > 0L) dao.soilTests(farmId) else flowOf(emptyList()) }
    val soilTests by soilFlow.collectAsState(initial = emptyList())
    val harvestFlow = remember(farmId) { if (farmId > 0L) dao.harvestRecords(farmId) else flowOf(emptyList()) }
    val harvests by harvestFlow.collectAsState(initial = emptyList())
    val ledgerFlow = remember(farmId) { if (farmId > 0) dao.ledger(farmId) else flowOf(emptyList()) }
    val incomeFlow = remember(farmId) { if (farmId > 0) dao.incomeKobo(farmId) else flowOf(0L) }
    val expenseFlow = remember(farmId) { if (farmId > 0) dao.expensesKobo(farmId) else flowOf(0L) }
    val ledger by ledgerFlow.collectAsState(initial = emptyList())
    val incomeKobo by incomeFlow.collectAsState(initial = 0L)
    val expenseKobo by expenseFlow.collectAsState(initial = 0L)

    MaterialTheme(colorScheme = lightColorScheme(primary = AlsasGreen, secondary = AlsasGreen)) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("ALSAS AGRO TECH", fontWeight = FontWeight.Bold)
                            Text("Your Farm. Your Records. Your Profit.", style = MaterialTheme.typography.labelSmall)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = AlsasPale)
                )
            },
            bottomBar = {
                NavigationBar {
                    listOf("Home", "Gona", "Lissafi", "Kasuwa", "Koyo", "Bayani").forEach { label ->
                        NavigationBarItem(
                            selected = tab == label,
                            onClick = { tab = label },
                            icon = { Text(when (label) { "Home" -> "⌂"; "Gona" -> "🌱"; "Lissafi" -> "₦"; "Kasuwa" -> "🛒"; else -> "📚" }) },
                            label = { Text(label) }
                        )
                    }
                }
            }
        ) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(vertical = 16.dp)
            ) {
                when (tab) {
                    "Home" -> {
                        item { Card(onClick = { tab = "Bayani" }, modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp)) { Text("Bayanan manomi", fontWeight = FontWeight.Bold); Text(farmerProfile?.fullName ?: "Kammala rajistar bayananka") } } }
                        item { Text("Barka da zuwa!", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }
                        item { Text("Gudanar da gonarka cikin sauƙi", color = Color.Gray) }
                        item { SummaryCard("Gonaki", farms.size.toString()) }
                        item { Text("Lissafin gonar da aka zaɓa: ${selectedFarm?.farmName ?: "Babu gona"}", color = Color.Gray) }
                        item { SummaryCard("Kuɗin shiga", money(incomeKobo)) }
                        item { SummaryCard("Kuɗin kashewa", money(expenseKobo)) }
                        item { SummaryCard("Riba / Asara", money(incomeKobo - expenseKobo)) }
                        item { Text("Gonakina", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
                        items(farms, key = { it.id }) { farm ->
                            Card(onClick = { selectedFarmId = farm.id; tab = "Lissafi" }, modifier = Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(14.dp)) {
                                    Text(farm.farmName, fontWeight = FontWeight.SemiBold)
                                    Text("${farm.crop} • ${farm.hectares} ha • ${farm.season}", color = Color.Gray)
                                    val place = listOf(farm.village, farm.localGovernment, farm.state).filter { it.isNotBlank() }.joinToString(", ")
                                    if (place.isNotBlank()) Text(place, color = Color.Gray)
                                    if (farm.variety.isNotBlank()) Text("Iri: ${farm.variety}", color = Color.Gray)
                                }
                            }
                        }
                        if (farms.isEmpty()) item { Text("Ba ka ƙara gonarka ba tukuna. Je zuwa shafin Gona domin farawa.", color = Color.Gray) }
                    }
                    "Bayani" -> {
                        item { FarmerProfileForm(dao, farmerProfile, scope) }
                    }
                    "Gona" -> {
                        item { FarmManagement(dao, farms, selectedFarmId, { selectedFarmId = it }, scope) }
                        if (selectedFarm != null) {
                            item { FarmActivityCalendar(dao, farmId, farmTasks, scope) }
                        } else {
                            item { InfoCard("Jadawalin ayyukan gona", "Da farko ka ƙara gona sannan ka zaɓa domin tsara ayyukanta.") }
                        }
                    }
                    "Lissafi" -> {
                        item {
                            Text("Lissafin gonar", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                            if (farms.isNotEmpty()) {
                                var expanded by remember { mutableStateOf(false) }
                                ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
                                    OutlinedTextField(
                                        value = selectedFarm?.farmName ?: "Zaɓi gona",
                                        onValueChange = {}, readOnly = true,
                                        label = { Text("Gonar da ake lissafawa") },
                                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
                                        modifier = Modifier.menuAnchor().fillMaxWidth()
                                    )
                                    ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                                        farms.forEach { farm ->
                                            DropdownMenuItem(text = { Text(farm.farmName) }, onClick = { selectedFarmId = farm.id; expanded = false })
                                        }
                                    }
                                }
                            }
                        }
                        item { InputCalculatorCard(selectedFarm?.hectares) }
                        if (selectedFarm != null) {
                            item { SoilTestForm(dao, farmId, soilTests, scope) }
                        }
                        item { SummaryCard("Jimillar kuɗin shiga", money(incomeKobo)) }
                        item { SummaryCard("Jimillar kashewa", money(expenseKobo)) }
                        item { SummaryCard("Riba / Asara", money(incomeKobo - expenseKobo)) }
                        if (selectedFarm != null) {
                            item { AddLedgerForm(dao, farmId, scope) }
                            item { HarvestRecordForm(dao, farmId, selectedFarm.crop, harvests, scope) }
                            item {
                                val harvestedKg = harvests.sumOf { it.quantityKg }
                                val lossesKg = harvests.sumOf { it.lossKg }
                                val estimatedSalesKobo = harvests.sumOf { record ->
                                    if (record.salePricePerBagKobo > 0 && record.bagsCount > 0)
                                        (record.salePricePerBagKobo.toDouble() * record.bagsCount).toLong()
                                    else 0L
                                }
                                val yieldPerHectare = if (selectedFarm.hectares > 0.0) harvestedKg / selectedFarm.hectares else 0.0
                                Card(Modifier.fillMaxWidth()) {
                                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Text("Rahoton samarwa da riba", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                                        Text("Jimillar girbi: ${String.format(Locale.US, "%.2f", harvestedKg)} kg")
                                        Text("Asarar amfanin gona: ${String.format(Locale.US, "%.2f", lossesKg)} kg")
                                        Text("Yawan girbi a hectare: ${String.format(Locale.US, "%.2f", yieldPerHectare)} kg/ha")
                                        Text("Kiyasin kuɗin sayarwa daga bayanan buhu: ${money(estimatedSalesKobo)}")
                                        Divider()
                                        Text("Ribar lissafin kuɗi: ${money(incomeKobo - expenseKobo)}", fontWeight = FontWeight.Bold, color = if (incomeKobo >= expenseKobo) AlsasGreen else Color.Red)
                                        Text("Ana lissafa riba daga kuɗin shiga da kashewa da aka rubuta. Kiyasin sayarwar girbi ba a haɗa shi sau biyu cikin ribar ba.", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            OutlinedButton(onClick = {
                                                val rows = mutableListOf(
                                                    listOf("ALSAS AGRO TECH - Farm Report"),
                                                    listOf("Farm", selectedFarm.farmName),
                                                    listOf("Crop", selectedFarm.crop),
                                                    listOf("Area (ha)", selectedFarm.hectares.toString()),
                                                    listOf("Season", selectedFarm.season),
                                                    listOf("Income (NGN)", (incomeKobo / 100.0).toString()),
                                                    listOf("Expenses (NGN)", (expenseKobo / 100.0).toString()),
                                                    listOf("Profit/Loss (NGN)", ((incomeKobo - expenseKobo) / 100.0).toString()),
                                                    listOf("Harvest (kg)", harvestedKg.toString()),
                                                    listOf("Loss (kg)", lossesKg.toString()),
                                                    listOf("Harvest date", "Crop", "Quantity kg", "Bags", "Loss kg", "Sale price/bag NGN")
                                                )
                                                harvests.forEach { h -> rows.add(listOf(java.text.SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(h.harvestDateMillis)), h.cropName, h.quantityKg.toString(), h.bagsCount.toString(), h.lossKg.toString(), (h.salePricePerBagKobo / 100.0).toString())) }
                                                ledger.forEach { e -> rows.add(listOf(if (e.kind == "INCOME") "Income" else "Expense", e.title, (e.amountKobo / 100.0).toString(), e.category, java.text.SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(e.dateMillis)))) }
                                                exportBytes = CsvReport.document(rows).toByteArray(Charsets.UTF_8)
                                                exportLauncher.launch("ALSAS_${selectedFarm.farmName.replace(Regex("[^A-Za-z0-9_-]"), "_")}_report.csv")
                                            }) { Text("Fitar da CSV") }
                                            OutlinedButton(onClick = {
                                                val pdf = PdfDocument()
                                                val page = pdf.startPage(PdfDocument.PageInfo.Builder(595, 842, 1).create())
                                                val paint = Paint().apply { textSize = 13f }
                                                val lines = listOf("ALSAS AGRO TECH - FARM REPORT", "Farm: ${selectedFarm.farmName}", "Crop: ${selectedFarm.crop}", "Area: ${selectedFarm.hectares} ha", "Season: ${selectedFarm.season}", "Income: ${money(incomeKobo)}", "Expenses: ${money(expenseKobo)}", "Profit/Loss: ${money(incomeKobo - expenseKobo)}", "Harvest: $harvestedKg kg", "Loss: $lossesKg kg", "Yield: $yieldPerHectare kg/ha", "", "Ledger entries: ${ledger.size}", "Harvest records: ${harvests.size}")
                                                lines.forEachIndexed { index, line -> page.canvas.drawText(line, 40f, 55f + index * 24f, paint) }
                                                pdf.finishPage(page)
                                                val output = ByteArrayOutputStream(); pdf.writeTo(output); pdf.close()
                                                exportBytes = output.toByteArray()
                                                exportLauncher.launch("ALSAS_${selectedFarm.farmName.replace(Regex("[^A-Za-z0-9_-]"), "_")}_report.pdf")
                                            }) { Text("Fitar da PDF") }
                                        }
                                    }
                                }
                            }
                        }
                        item { Text("Tarihin kuɗi", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
                        items(ledger, key = { it.id }) { entry ->
                            Card(Modifier.fillMaxWidth()) {
                                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text(entry.title, fontWeight = FontWeight.SemiBold)
                                        Text(if (entry.kind == "INCOME") "Kuɗin shiga" else "Kuɗin kashewa", color = Color.Gray)
                                    }
                                    Text((if (entry.kind == "INCOME") "+" else "−") + money(entry.amountKobo),
                                        color = if (entry.kind == "INCOME") AlsasGreen else Color.DarkGray, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                        if (selectedFarm == null) item { Text("Da farko ka ƙara gona a shafin Gona.", color = Color.Gray) }
                    }
                    "Kasuwa" -> {
                        item { Text("Kasuwar ALSAS", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
                        item { Text("Wannan sashe zai ƙunshi ALSAS Suppliers da Marketplace. Za a nuna kayayyaki da farashi ne kawai bayan ALSAS ta tabbatar da su.") }
                        item { InfoCard("ALSAS Suppliers", "Neman kayan noma da quotation: taki, iri, agrochemicals, injina da ban-ruwa.") }
                        item { InfoCard("Agricultural Marketplace", "Tallata shinkafa, masara, waken soya, wake da sauran amfanin gona. Ana buƙatar backend kafin wallafa tallace-tallace a intanet.") }
                    }
                    "Koyo" -> {
                        item { Text("ALSAS Farmer Academy", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
                        item { Text("Darussan Hausa da English kan noma, daga shuka zuwa girbi da tallata amfanin gona.") }
                        listOf("Gwajin tsiron iri", "Gwajin ƙasa da pH", "Rarraba taki", "Gane kwari masu cutarwa da masu amfani", "Integrated Pest Management", "Girbi, busarwa da adanawa", "Packaging da tallata amfanin gona").forEach { lesson ->
                            item { InfoCard(lesson, "Za a shigar da ingantaccen darasi a wannan sashe.") }
                        }
                    }
                }
                item { Text("MVP prototype • Bayanai na gona da lissafi ana adana su a wannan na'ura.", color = Color.Gray, style = MaterialTheme.typography.bodySmall) }
            }
        }
    }
}

@Composable
private fun FarmManagement(
    dao: com.alsas.agrotech.data.FarmDao,
    farms: List<FarmRecord>,
    selectedFarmId: Long,
    onSelect: (Long) -> Unit,
    scope: kotlinx.coroutines.CoroutineScope
) {
    var farmName by remember { mutableStateOf("") }
    var hectares by remember { mutableStateOf("") }
    var crop by remember { mutableStateOf("Masara") }
    var season by remember { mutableStateOf("Damina") }
    var state by remember { mutableStateOf("") }
    var lga by remember { mutableStateOf("") }
    var village by remember { mutableStateOf("") }
    var locationNote by remember { mutableStateOf("") }
    var variety by remember { mutableStateOf("") }
    var editingId by remember { mutableLongStateOf(0L) }
    var formError by remember { mutableStateOf<String?>(null) }
    var isSaving by remember { mutableStateOf(false) }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Gudanar da gonaki", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        OutlinedTextField(farmName, { farmName = it }, label = { Text("Sunan gona") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(hectares, { hectares = it.filter { c -> c.isDigit() || c == '.' || c == ',' }.replace(',', '.') }, label = { Text("Girman gona (hectare)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth())
        CropDropdown(crop, { crop = it })
        SeasonDropdown(season, { season = it })
        Text("Wurin da gonar take", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        OutlinedTextField(state, { state = it }, label = { Text("Jiha") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(lga, { lga = it }, label = { Text("Ƙaramar hukuma") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(village, { village = it }, label = { Text("Gari / ƙauye") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(locationNote, { locationNote = it }, label = { Text("Ƙarin bayani kan wurin gona (misali kusa da hanya ko kogi)") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(variety, { variety = it }, label = { Text("Irin amfanin gona / variety (idan akwai)") }, modifier = Modifier.fillMaxWidth())
        Button(onClick = {
            val area = hectares.toDoubleOrNull()
            formError = when {
                farmName.isBlank() -> "Shigar da sunan gona."
                area == null || !area.isFinite() || area <= 0.0 -> "Shigar da girman gona mai inganci fiye da sifili."
                else -> null
            }
            if (formError == null && area != null) {
                scope.launch {
                    isSaving = true
                    try {
                        if (editingId == 0L) {
                            val id = dao.addFarm(FarmRecord(farmName = farmName.trim(), crop = crop, hectares = area, season = season, state = state.trim(), localGovernment = lga.trim(), village = village.trim(), locationNote = locationNote.trim(), variety = variety.trim()))
                            onSelect(id)
                        } else {
                            val original = farms.firstOrNull { it.id == editingId }
                            dao.updateFarm(FarmRecord(
                                id = editingId,
                                farmName = farmName.trim(),
                                crop = crop,
                                hectares = area,
                                season = season,
                                state = state.trim(),
                                localGovernment = lga.trim(),
                                village = village.trim(),
                                locationNote = locationNote.trim(),
                                variety = variety.trim(),
                                plantingDateMillis = original?.plantingDateMillis,
                                expectedHarvestMillis = original?.expectedHarvestMillis,
                                createdAt = original?.createdAt ?: System.currentTimeMillis()
                            ))
                        }
                        farmName = ""; hectares = ""; state = ""; lga = ""; village = ""; locationNote = ""; variety = ""; editingId = 0L; formError = null
                    } catch (_: Exception) {
                        formError = "An samu matsala wajen ajiye gonar. Ka sake gwadawa."
                    } finally {
                        isSaving = false
                    }
                }
            }
        }, enabled = !isSaving, modifier = Modifier.fillMaxWidth()) { Text(if (isSaving) "Ana ajiyewa…" else if (editingId == 0L) "Ajiye sabuwar gona" else "Sabunta gona") }
        formError?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
        if (editingId != 0L) TextButton(onClick = { editingId = 0L; farmName = ""; hectares = ""; formError = null }) { Text("Soke gyara") }
        Text("Gonakinka", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        farms.forEach { farm ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(farm.farmName, fontWeight = FontWeight.Bold)
                    Text("${farm.crop} • ${farm.hectares} ha • ${farm.season}", color = Color.Gray)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextButton(onClick = { onSelect(farm.id); editingId = farm.id; farmName = farm.farmName; hectares = farm.hectares.toString(); crop = farm.crop; season = farm.season; state = farm.state; lga = farm.localGovernment; village = farm.village; locationNote = farm.locationNote; variety = farm.variety }) { Text("Gyara") }
                        TextButton(onClick = { onSelect(farm.id) }) { Text("Zaɓa") }
                        TextButton(onClick = {
                            scope.launch {
                                try {
                                    dao.deleteFarmAndRelatedData(farm)
                                    if (selectedFarmId == farm.id) onSelect(0L)
                                    if (editingId == farm.id) { editingId = 0L; farmName = ""; hectares = "" }
                                } catch (_: Exception) {
                                    formError = "An samu matsala wajen goge gonar. Ba a tabbatar an goge ta ba."
                                }
                            }
                        }) { Text("Goge") }
                    }
                }
            }
        }
    }
}

@Composable
private fun FarmActivityCalendar(
    dao: com.alsas.agrotech.data.FarmDao,
    farmId: Long,
    tasks: List<FarmTask>,
    scope: kotlinx.coroutines.CoroutineScope
) {
    var title by remember(farmId) { mutableStateOf("") }
    var dateText by remember(farmId) { mutableStateOf("") }
    var note by remember(farmId) { mutableStateOf("") }
    var error by remember(farmId) { mutableStateOf<String?>(null) }
    var saving by remember(farmId) { mutableStateOf(false) }
    val dateParser = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { isLenient = false; timeZone = TimeZone.getDefault() } }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Jadawalin ayyukan gona", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text("Rubuta shuka, taki, feshi, ban-ruwa, cire ciyawa, girbi ko wani aiki. Tsarin tunatarwa ta wayar ba a kunna ba tukuna.", color = Color.Gray)
        OutlinedTextField(title, { title = it }, label = { Text("Aikin da za a yi") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(dateText, { dateText = it }, label = { Text("Ranar aiki (YYYY-MM-DD)") }, supportingText = { Text("Misali: 2026-11-15") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(note, { note = it }, label = { Text("Ƙarin bayani (zaɓi ne)") }, modifier = Modifier.fillMaxWidth())
        Button(enabled = !saving, onClick = {
            val parsed = runCatching {
                val input = dateText.trim(); val position = ParsePosition(0)
                val value = dateParser.parse(input, position)
                value?.time?.takeIf { position.index == input.length }
            }.getOrNull()
            if (title.isBlank()) error = "Shigar da sunan aikin."
            else if (parsed == null) error = "Ranar ba ta dace ba. Yi amfani da YYYY-MM-DD."
            else {
                error = null; saving = true
                scope.launch {
                    try {
                        dao.addTask(FarmTask(farmId = farmId, title = title.trim(), dueDateMillis = parsed, note = note.trim()))
                        title = ""; dateText = ""; note = ""
                    } catch (_: Exception) { error = "An kasa ajiye aikin. Ka sake gwadawa." }
                    finally { saving = false }
                }
            }
        }, modifier = Modifier.fillMaxWidth()) { Text(if (saving) "Ana ajiyewa…" else "Ajiye aikin") }
        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        Text("Ayyukan da aka tsara", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        if (tasks.isEmpty()) Text("Babu aikin da aka tsara tukuna.", color = Color.Gray)
        tasks.forEach { task ->
            Card(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = task.completed, onCheckedChange = { checked -> scope.launch { dao.markTask(task.id, checked) } })
                    Column(Modifier.weight(1f)) {
                        Text(task.title, fontWeight = FontWeight.SemiBold)
                        Text(dateParser.format(Date(task.dueDateMillis)) + if (task.completed) " • An kammala" else " • Ana jira", color = Color.Gray)
                        if (task.note.isNotBlank()) Text(task.note, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}

@Composable
private fun CropDropdown(value: String, onChange: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Box {
        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text("Amfanin gona: $value") }
        DropdownMenu(expanded, { expanded = false }) {
            listOf("Masara", "Shinkafa", "Wake", "Waken soya", "Sorghum", "Alkama", "Gyada").forEach { option ->
                DropdownMenuItem(text = { Text(option) }, onClick = { onChange(option); expanded = false })
            }
        }
    }
}

@Composable
private fun SeasonDropdown(value: String, onChange: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Box {
        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text("Lokacin noma: $value") }
        DropdownMenu(expanded, { expanded = false }) {
            listOf("Damina", "Rani", "Duk shekara").forEach { option ->
                DropdownMenuItem(text = { Text(option) }, onClick = { onChange(option); expanded = false })
            }
        }
    }
}

@Composable
private fun AddLedgerForm(dao: com.alsas.agrotech.data.FarmDao, farmId: Long, scope: kotlinx.coroutines.CoroutineScope) {
    var title by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var kind by remember { mutableStateOf("EXPENSE") }
    var category by remember { mutableStateOf("Other") }
    var formError by remember { mutableStateOf<String?>(null) }
    var isSaving by remember { mutableStateOf(false) }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Ƙara bayanin kuɗi", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        OutlinedTextField(title, { title = it }, label = { Text("Abin da aka saya ko sayar") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(amount, { amount = it.filter { c -> c.isDigit() || c == '.' || c == ',' } }, label = { Text("Adadin kuɗi (₦)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = kind == "EXPENSE", onClick = { kind = "EXPENSE" }, label = { Text("Kashewa") })
            FilterChip(selected = kind == "INCOME", onClick = { kind = "INCOME" }, label = { Text("Shiga") })
        }
        OutlinedTextField(category, { category = it }, label = { Text("Rukuni (misali: iri, taki, aiki, sayarwa)") }, modifier = Modifier.fillMaxWidth())
        Button(onClick = {
            val kobo = parseNairaToKobo(amount)
            formError = when {
                farmId <= 0L -> "Da farko ka zaɓi gona."
                title.isBlank() -> "Shigar da bayanin kuɗin."
                amount.isBlank() -> "Shigar da adadin kuɗi."
                kobo == null -> "Adadin kuɗin bai dace ba. Yi amfani da adadi mai kyau, decimal biyu ko ƙasa da haka (misali 250.50)."
                else -> null
            }
            if (formError == null && kobo != null) scope.launch {
                isSaving = true
                try {
                    dao.addLedger(LedgerEntry(farmId = farmId, title = title.trim(), amountKobo = kobo, kind = kind, category = category.trim()))
                    title = ""; amount = ""; formError = null
                } catch (_: Exception) {
                    formError = "An samu matsala wajen ajiye bayanin kuɗi. Ka sake gwadawa."
                } finally {
                    isSaving = false
                }
            }
        }, enabled = !isSaving, modifier = Modifier.fillMaxWidth()) { Text(if (isSaving) "Ana ajiyewa…" else "Ajiye bayanin kuɗi") }
        formError?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
    }
}

@Composable
private fun SummaryCard(title: String, value: String) {
    Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = AlsasPale), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(14.dp)) {
            Text(title, color = Color.DarkGray, style = MaterialTheme.typography.bodySmall)
            Text(value, color = AlsasGreen, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
        }
    }
}

@Composable
private fun InfoCard(title: String, description: String) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(description, color = Color.Gray)
        }
    }
}

private fun money(kobo: Long): String = naira.format(java.math.BigDecimal.valueOf(kobo, 2))


@Composable
private fun FarmerProfileForm(dao: com.alsas.agrotech.data.FarmDao, profile: FarmerProfile?, scope: kotlinx.coroutines.CoroutineScope) {
    var name by remember(profile) { mutableStateOf(profile?.fullName ?: "") }
    var phone by remember(profile) { mutableStateOf(profile?.phone ?: "") }
    var state by remember(profile) { mutableStateOf(profile?.state ?: "") }
    var lga by remember(profile) { mutableStateOf(profile?.localGovernment ?: "") }
    var village by remember(profile) { mutableStateOf(profile?.village ?: "") }
    var language by remember(profile) { mutableStateOf(profile?.preferredLanguage ?: "Hausa") }
    var message by remember { mutableStateOf<String?>(null) }
    var saving by remember { mutableStateOf(false) }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Bayanan manomi", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text("Wannan rajista ce ta bayanan gida a wannan waya kawai; ba rajistar asusun intanet ba tukuna.", color = Color.Gray, style = MaterialTheme.typography.bodySmall)
        OutlinedTextField(name, { name = it }, label = { Text("Cikakken suna") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(phone, { phone = it.filter { c -> c.isDigit() || c == '+' } }, label = { Text("Lambar waya") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), modifier = Modifier.fillMaxWidth())
        OutlinedTextField(state, { state = it }, label = { Text("Jiha") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(lga, { lga = it }, label = { Text("Ƙaramar hukuma") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(village, { village = it }, label = { Text("Gari / ƙauye") }, modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = language == "Hausa", onClick = { language = "Hausa" }, label = { Text("Hausa") })
            FilterChip(selected = language == "English", onClick = { language = "English" }, label = { Text("English") })
        }
        Button(enabled = !saving, onClick = {
            message = when { name.isBlank() -> "Shigar da cikakken suna."; phone.filter { it.isDigit() }.length < 10 -> "Shigar da lambar waya mai inganci."; state.isBlank() -> "Shigar da jiha."; lga.isBlank() -> "Shigar da ƙaramar hukuma."; else -> null }
            if (message == null) scope.launch {
                saving = true
                try { dao.saveFarmerProfile(FarmerProfile(fullName = name.trim(), phone = phone.trim(), state = state.trim(), localGovernment = lga.trim(), village = village.trim(), preferredLanguage = language)); message = "An adana bayananka a wannan waya." }
                catch (_: Exception) { message = "An samu matsala wajen adanawa. Ka sake gwadawa." }
                finally { saving = false }
            }
        }, modifier = Modifier.fillMaxWidth()) { Text(if (saving) "Ana ajiyewa…" else "Ajiye bayanai") }
        message?.let { Text(it, color = if (it.startsWith("An adana")) AlsasGreen else MaterialTheme.colorScheme.error) }
    }
}


@Composable
private fun HarvestRecordForm(dao: com.alsas.agrotech.data.FarmDao, farmId: Long, defaultCrop: String, records: List<HarvestRecord>, scope: kotlinx.coroutines.CoroutineScope) {
    var crop by remember(farmId) { mutableStateOf(defaultCrop) }
    var kg by remember(farmId) { mutableStateOf("") }
    var bags by remember(farmId) { mutableStateOf("") }
    var bagWeight by remember(farmId) { mutableStateOf("100") }
    var loss by remember(farmId) { mutableStateOf("0") }
    var price by remember(farmId) { mutableStateOf("") }
    var date by remember(farmId) { mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())) }
    var note by remember(farmId) { mutableStateOf("") }
    var error by remember(farmId) { mutableStateOf<String?>(null) }
    var saving by remember(farmId) { mutableStateOf(false) }
    val parser = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { isLenient = false } }
    val totalKg = records.sumOf { it.quantityKg }
    val totalLoss = records.sumOf { it.lossKg }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Bayanan girbi da samarwa", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text("Shigar da ainihin adadin da aka auna. Ana amfani da farashin buhu ne kawai idan ka shigar da shi.", color = Color.Gray)
        OutlinedTextField(crop, { crop = it }, label = { Text("Amfanin gona") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(date, { date = it }, label = { Text("Ranar girbi (YYYY-MM-DD)") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(kg, { kg = it }, label = { Text("Jimillar nauyi (kg)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth())
        OutlinedTextField(bags, { bags = it }, label = { Text("Yawan buhu") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth())
        OutlinedTextField(bagWeight, { bagWeight = it }, label = { Text("Nauyin buhu guda (kg)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth())
        OutlinedTextField(loss, { loss = it }, label = { Text("Asarar amfanin gona (kg)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth())
        OutlinedTextField(price, { price = it }, label = { Text("Farashin sayar da buhu guda (₦, zaɓi ne)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth())
        OutlinedTextField(note, { note = it }, label = { Text("Bayani / inganci / ajiya") }, modifier = Modifier.fillMaxWidth())
        Button(enabled = !saving, onClick = {
            val q = kg.toDoubleOrNull(); val b = bags.toDoubleOrNull(); val bw = bagWeight.toDoubleOrNull(); val l = loss.toDoubleOrNull()
            val d = runCatching {
                val input = date.trim(); val position = ParsePosition(0)
                val value = parser.parse(input, position)
                value?.time?.takeIf { position.index == input.length }
            }.getOrNull()
            val p = if (price.isBlank()) 0L else parseNairaToKobo(price)
            error = when { crop.isBlank() -> "Shigar da amfanin gonar."; d == null -> "Ranar girbi ba ta dace ba."; q == null || !q.isFinite() || q <= 0 -> "Nauyin girbi dole ya fi sifili."; b == null || !b.isFinite() || b < 0 -> "Yawan buhu bai dace ba."; bw == null || !bw.isFinite() || bw <= 0 -> "Nauyin buhu bai dace ba."; l == null || !l.isFinite() || l < 0 || l > q -> "Asara dole ta kasance daga sifili zuwa jimillar nauyi."; p == null -> "Farashin bai dace ba."; else -> null }
            if (error == null && q != null && b != null && bw != null && l != null && d != null && p != null) scope.launch {
                saving = true
                try { dao.addHarvest(HarvestRecord(farmId=farmId, cropName=crop.trim(), harvestDateMillis=d, quantityKg=q, bagsCount=b, bagWeightKg=bw, lossKg=l, salePricePerBagKobo=p, notes=note.trim())); kg=""; bags=""; loss="0"; price=""; note=""; error="An adana bayanan girbi." }
                catch (_: Exception) { error="An kasa adana bayanan girbi." } finally { saving=false }
            }
        }, modifier = Modifier.fillMaxWidth()) { Text(if (saving) "Ana ajiyewa…" else "Ajiye bayanan girbi") }
        error?.let { Text(it, color = if (it.startsWith("An adana")) AlsasGreen else MaterialTheme.colorScheme.error) }
        SummaryCard("Jimillar girbi (kg)", String.format(Locale.US, "%.2f", totalKg))
        SummaryCard("Jimillar asara (kg)", String.format(Locale.US, "%.2f", totalLoss))
        Text("Tarihin girbi", fontWeight = FontWeight.Bold)
        if (records.isEmpty()) Text("Ba a shigar da bayanan girbi ba tukuna.", color = Color.Gray)
        records.forEach { r -> Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp)) { Text(r.cropName, fontWeight = FontWeight.Bold); Text("${parser.format(Date(r.harvestDateMillis))} • ${r.quantityKg} kg • ${r.bagsCount} buhu"); Text("Asara: ${r.lossKg} kg • Buhu: ${r.bagWeightKg} kg"); if (r.salePricePerBagKobo > 0) Text("Farashin buhu: ${money(r.salePricePerBagKobo)}"); if (r.notes.isNotBlank()) Text(r.notes, color=Color.Gray) } } }
    }
}


@Composable
private fun InputCalculatorCard(defaultAreaHa: Double?) {
    var area by remember(defaultAreaHa) { mutableStateOf(defaultAreaHa?.takeIf { it > 0 }?.toString() ?: "1") }
    var nutrientRate by remember { mutableStateOf("") }
    var fertilizerGrade by remember { mutableStateOf("") }
    var seedRate by remember { mutableStateOf("") }
    var tankCount by remember { mutableStateOf("") }
    var tankCapacity by remember { mutableStateOf("15") }
    var labelRate by remember { mutableStateOf("") }
    val areaValue = area.toDoubleOrNull()
    val fertilizerResult = runCatching {
        InputCalculator.fertilizerProductKg(areaValue ?: 0.0, nutrientRate.toDoubleOrNull() ?: -1.0, fertilizerGrade.toDoubleOrNull() ?: 0.0)
    }.getOrNull()
    val seedResult = runCatching {
        InputCalculator.seedQuantityKg(areaValue ?: 0.0, seedRate.toDoubleOrNull() ?: -1.0)
    }.getOrNull()
    val sprayResult = runCatching {
        InputCalculator.sprayProductMl(tankCount.toDoubleOrNull() ?: -1.0, labelRate.toDoubleOrNull() ?: -1.0)
    }.getOrNull()
    val waterResult = runCatching {
        InputCalculator.totalWaterLitres(tankCount.toDoubleOrNull() ?: -1.0, tankCapacity.toDoubleOrNull() ?: 0.0)
    }.getOrNull()
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Kalkuleta kayan noma", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text("Shigar da ƙimar da aka tabbatar daga gwajin ƙasa, shawarar masanin gona ko lakabin samfur. Wannan kalkuleta ba ya ƙirƙirar adadin taki ko magani.", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
            OutlinedTextField(area, { area = it }, label = { Text("Girman fili (hectare)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth(), singleLine = true)
            Divider()
            Text("1. Taki", fontWeight = FontWeight.SemiBold)
            OutlinedTextField(nutrientRate, { nutrientRate = it }, label = { Text("Adadin sinadarin da ake buƙata (kg/ha)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth(), singleLine = true)
            OutlinedTextField(fertilizerGrade, { fertilizerGrade = it }, label = { Text("Kason sinadarin a jikin taki (%)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth(), singleLine = true)
            Text(if (fertilizerResult != null) "Adadin takin da ake buƙata: ${String.format(Locale.US, "%.2f", fertilizerResult)} kg" else "Cika bayanan taki da ingantattun ƙimomi domin samun lissafi.", fontWeight = FontWeight.Medium)
            Divider()
            Text("2. Iri", fontWeight = FontWeight.SemiBold)
            OutlinedTextField(seedRate, { seedRate = it }, label = { Text("Adadin iri bisa shawara (kg/ha)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth(), singleLine = true)
            Text(if (seedResult != null) "Jimillar iri: ${String.format(Locale.US, "%.2f", seedResult)} kg" else "Shigar da adadin iri da aka amince da shi ga amfanin gonar.")
            Divider()
            Text("3. Fesawa", fontWeight = FontWeight.SemiBold)
            OutlinedTextField(tankCount, { tankCount = it }, label = { Text("Yawan tankunan feshi") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth(), singleLine = true)
            OutlinedTextField(tankCapacity, { tankCapacity = it }, label = { Text("Girman tanki (lita)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth(), singleLine = true)
            OutlinedTextField(labelRate, { labelRate = it }, label = { Text("Adadin magani bisa tanki (ml, kamar yadda lakabi ya nuna)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth())
            if (waterResult != null) Text("Jimillar ruwan feshi: ${String.format(Locale.US, "%.2f", waterResult)} L")
            if (sprayResult != null) Text("Jimillar magani bisa lakabi: ${String.format(Locale.US, "%.2f", sprayResult)} ml", fontWeight = FontWeight.Medium)
            Text("Muhimmi: Kada a yi amfani da ƙiyasin nan a matsayin shawarar feshi. Bi lakabin samfur, amfanin gonar da aka amince da shi, kayan kariya da dokokin gida. Idan ba ka da tabbataccen adadi, tuntuɓi ƙwararren agronomist.", style = MaterialTheme.typography.bodySmall, color = Color(0xFF8A4B08))
        }
    }
}


@Composable
private fun SoilTestForm(dao: com.alsas.agrotech.data.FarmDao, farmId: Long, records: List<SoilTestRecord>, scope: kotlinx.coroutines.CoroutineScope) {
    var ph by remember { mutableStateOf("") }
    var n by remember { mutableStateOf("") }
    var p by remember { mutableStateOf("") }
    var k by remember { mutableStateOf("") }
    var organic by remember { mutableStateOf("") }
    var texture by remember { mutableStateOf("") }
    var lab by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    val phValue = ph.toDoubleOrNull()
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Gwajin ƙasa (Soil Test)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text("Shigar da sakamakon dakin gwaje-gwaje kawai. Kada a ɗauki fassarar nan a matsayin takardar gwaji.", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
            OutlinedTextField(ph, { ph = it }, label = { Text("pH (0–14)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth())
            OutlinedTextField(n, { n = it }, label = { Text("Nitrogen (mg/kg)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth())
            OutlinedTextField(p, { p = it }, label = { Text("Phosphorus (mg/kg)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth())
            OutlinedTextField(k, { k = it }, label = { Text("Potassium (mg/kg)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth())
            OutlinedTextField(organic, { organic = it }, label = { Text("Organic matter (%)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth())
            OutlinedTextField(texture, { texture = it }, label = { Text("Nau'in ƙasa (sandy/clay/loam)") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(lab, { lab = it }, label = { Text("Sunan dakin gwaji") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(notes, { notes = it }, label = { Text("Ƙarin bayani") }, modifier = Modifier.fillMaxWidth())
            if (ph.isNotBlank()) Text(SoilInterpreter.interpretPh(phValue), color = AlsasGreen)
            Button(onClick = {
                val nv = n.toDoubleOrNull(); val pv = p.toDoubleOrNull(); val kv = k.toDoubleOrNull(); val ov = organic.toDoubleOrNull()
                val validPh = ph.isBlank() || (phValue != null && phValue in 0.0..14.0)
                if (!validPh || !SoilInterpreter.validateNutrient(nv) || !SoilInterpreter.validateNutrient(pv) || !SoilInterpreter.validateNutrient(kv) || !SoilInterpreter.validateOrganicMatter(ov) || listOf(n,p,k,organic).any { it.isNotBlank() && it.toDoubleOrNull() == null }) {
                    message = "Duba lambobin da ka shigar. pH 0–14 ne; sinadarai ba su zama ƙasa da sifili ba."
                } else {
                    scope.launch {
                        message = "Ana ajiyewa…"
                        try {
                            dao.addSoilTest(SoilTestRecord(farmId=farmId, ph=phValue, nitrogenMgKg=nv, phosphorusMgKg=pv, potassiumMgKg=kv, organicMatterPercent=ov, texture=texture.ifBlank { "Unknown" }, laboratory=lab.trim(), notes=notes.trim()))
                            message = "An adana sakamakon gwajin ƙasa."
                            ph = ""; n = ""; p = ""; k = ""; organic = ""; texture = ""; lab = ""; notes = ""
                        } catch (_: Exception) {
                            message = "An kasa adana sakamakon gwajin ƙasa. Ka sake gwadawa."
                        }
                    }
                }
            }, modifier = Modifier.fillMaxWidth()) { Text("Ajiye sakamakon gwaji") }
            if (message.isNotBlank()) Text(message, color = if (message.startsWith("An adana")) AlsasGreen else MaterialTheme.colorScheme.error)
            Text("Tarihin gwaje-gwaje: ${records.size}", fontWeight = FontWeight.SemiBold)
            records.take(5).forEach { record -> Text("${java.text.SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(record.testDateMillis))} • pH ${record.ph ?: "—"} • N ${record.nitrogenMgKg ?: "—"} • P ${record.phosphorusMgKg ?: "—"} • K ${record.potassiumMgKg ?: "—"}", style = MaterialTheme.typography.bodySmall) }
        }
    }
}
