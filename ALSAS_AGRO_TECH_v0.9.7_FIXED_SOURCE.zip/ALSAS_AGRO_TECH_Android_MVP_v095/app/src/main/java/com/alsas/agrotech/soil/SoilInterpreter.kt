package com.alsas.agrotech.soil

/** Conservative screening only. Thresholds are indicative; local lab/crop calibration is required. */
object SoilInterpreter {
    fun interpretPh(ph: Double?): String {
        if (ph == null) return "Ba a shigar da pH ba."
        if (!ph.isFinite() || ph !in 0.0..14.0) return "pH bai dace ba; shigar da ƙima tsakanin 0 da 14."
        return when {
            ph < 5.5 -> "Ƙasa mai tsananin acidity. A tabbatar da gwajin dakin gwaje-gwaje kafin amfani da lime."
            ph < 6.0 -> "Ƙasa mai acidity. Wasu amfanin gona na iya buƙatar gyaran ƙasa bisa shawarar gwani."
            ph <= 7.0 -> "pH yana kusa da yanayin da yawancin amfanin gona ke iya jurewa. Duba sauran sinadarai."
            ph <= 7.5 -> "Ƙasa mai ɗan alkaline. A duba samuwar phosphorus da micronutrients."
            else -> "Ƙasa mai alkaline. A nemi cikakken shawarar agronomist bisa amfanin gona da gwajin ƙasa."
        }
    }

    fun validateNutrient(value: Double?): Boolean = value == null || (value.isFinite() && value >= 0.0)
    fun validateOrganicMatter(value: Double?): Boolean = value == null || (value.isFinite() && value in 0.0..100.0)
}
