package com.alsas.agrotech.util

import java.math.BigDecimal

/**
 * Parses Naira to integer Kobo without floating-point rounding.
 * Accepts plain digits, decimal point, decimal comma (one/two trailing digits),
 * and conventional thousands grouping such as 1,250 or 1,250.75.
 */
fun parseNairaToKobo(input: String): Long? {
    val raw = input.trim()
    if (raw.isEmpty() || raw.any { !(it.isDigit() || it == ',' || it == '.') }) return null

    val normalized = when {
        raw.contains('.') && raw.contains(',') -> {
            // Commas must be valid thousands separators before the decimal point.
            val grouped = Regex("^[0-9]{1,3}(,[0-9]{3})+\\.[0-9]{1,2}$")
            if (!grouped.matches(raw)) return null
            raw.replace(",", "")
        }
        raw.contains(',') -> {
            val thousands = Regex("^[0-9]{1,3}(,[0-9]{3})+$")
            val decimalComma = Regex("^[0-9]+,[0-9]{1,2}$")
            when {
                thousands.matches(raw) -> raw.replace(",", "")
                decimalComma.matches(raw) -> raw.replace(',', '.')
                else -> return null
            }
        }
        else -> raw
    }

    val amount = normalized.toBigDecimalOrNull() ?: return null
    if (amount <= BigDecimal.ZERO || amount.stripTrailingZeros().scale() > 2) return null
    return runCatching { amount.movePointRight(2).longValueExact() }.getOrNull()
}
