package com.alsas.agrotech.calculators

/** Calculations use farmer-supplied label/rate values; this module does not prescribe rates. */
object InputCalculator {
    fun fertilizerProductKg(areaHa: Double, nutrientRateKgPerHa: Double, nutrientPercent: Double): Double {
        require(areaHa.isFinite() && areaHa > 0.0) { "Area must be greater than zero" }
        require(nutrientRateKgPerHa.isFinite() && nutrientRateKgPerHa >= 0.0) { "Nutrient rate cannot be negative" }
        require(nutrientPercent.isFinite() && nutrientPercent in 0.000001..100.0) { "Nutrient percentage must be above 0 and at most 100" }
        return areaHa * nutrientRateKgPerHa / (nutrientPercent / 100.0)
    }

    fun seedQuantityKg(areaHa: Double, seedRateKgPerHa: Double): Double {
        require(areaHa.isFinite() && areaHa > 0.0) { "Area must be greater than zero" }
        require(seedRateKgPerHa.isFinite() && seedRateKgPerHa >= 0.0) { "Seed rate cannot be negative" }
        return areaHa * seedRateKgPerHa
    }

    /** Product volume from a user-entered label rate in ml per sprayer tank. */
    fun sprayProductMl(tankCount: Double, labelRateMlPerTank: Double): Double {
        require(tankCount.isFinite() && tankCount >= 0.0) { "Tank count cannot be negative" }
        require(labelRateMlPerTank.isFinite() && labelRateMlPerTank >= 0.0) { "Label rate cannot be negative" }
        return tankCount * labelRateMlPerTank
    }

    fun totalWaterLitres(tankCount: Double, tankCapacityLitres: Double): Double {
        require(tankCount.isFinite() && tankCount >= 0.0) { "Tank count cannot be negative" }
        require(tankCapacityLitres.isFinite() && tankCapacityLitres > 0.0) { "Tank capacity must be greater than zero" }
        return tankCount * tankCapacityLitres
    }
}
