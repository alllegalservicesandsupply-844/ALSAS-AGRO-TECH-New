package com.alsas.agrotech.util

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class MoneyTest {
    @Test fun convertsWholeNaira() { assertEquals(125000L, parseNairaToKobo("1250")) }
    @Test fun convertsGroupedThousandsAndDecimal() { assertEquals(125075L, parseNairaToKobo("1,250.75")) }
    @Test fun convertsGroupedWholeThousands() { assertEquals(100000L, parseNairaToKobo("1,000")) }
    @Test fun acceptsDecimalComma() { assertEquals(25050L, parseNairaToKobo("250,50")) }
    @Test fun rejectsMoreThanTwoDecimalPlaces() { assertNull(parseNairaToKobo("10.001")) }
    @Test fun rejectsZeroNegativeAndInvalidValues() {
        assertNull(parseNairaToKobo("0")); assertNull(parseNairaToKobo("-2")); assertNull(parseNairaToKobo("abc"))
    }
    @Test fun rejectsOverflow() { assertNull(parseNairaToKobo("999999999999999999999999999999")) }
}
