package com.alsas.agrotech.util

import com.alsas.agrotech.reports.CsvReport
import org.junit.Assert.assertEquals
import org.junit.Test

class CsvReportTest {
    @Test fun quotesCommaAndNewline() {
        assertEquals("\"Rice, paddy\",\"line1\nline2\"", CsvReport.row("Rice, paddy", "line1\nline2"))
    }
    @Test fun doublesEmbeddedQuotes() {
        assertEquals("\"Farmer \"\"Sadiq\"\"\"", CsvReport.row("Farmer \"Sadiq\""))
    }
    @Test fun neutralizesSpreadsheetFormula() {
        assertEquals("\"'=2+2\"", CsvReport.row("=2+2"))
    }
    @Test fun neutralizesFormulaAfterLeadingWhitespace() {
        assertEquals("\"'  =2+2\"", CsvReport.row("  =2+2"))
    }
    @Test fun documentUsesCrLfAndFinalNewline() {
        assertEquals("\"A\",\"B\"\r\n\"1\",\"2\"\r\n", CsvReport.document(listOf(listOf("A", "B"), listOf("1", "2"))))
    }
}
