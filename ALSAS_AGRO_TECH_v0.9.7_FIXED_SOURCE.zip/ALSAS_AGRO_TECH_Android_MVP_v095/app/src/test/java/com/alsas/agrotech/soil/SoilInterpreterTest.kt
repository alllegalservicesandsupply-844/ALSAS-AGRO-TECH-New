package com.alsas.agrotech.soil

import org.junit.Assert.*
import org.junit.Test

class SoilInterpreterTest {
    @Test fun rejectsOutOfRangePh() { assertTrue(SoilInterpreter.interpretPh(15.0).contains("bai dace")) }
    @Test fun handlesMissingPh() { assertTrue(SoilInterpreter.interpretPh(null).contains("Ba a shigar")) }
    @Test fun flagsAcidicSoilConservatively() { assertTrue(SoilInterpreter.interpretPh(5.0).contains("acidity")) }
    @Test fun validatesNutrientsAndOrganicMatter() {
        assertFalse(SoilInterpreter.validateNutrient(-1.0))
        assertTrue(SoilInterpreter.validateNutrient(12.0))
        assertFalse(SoilInterpreter.validateOrganicMatter(101.0))
    }
}
