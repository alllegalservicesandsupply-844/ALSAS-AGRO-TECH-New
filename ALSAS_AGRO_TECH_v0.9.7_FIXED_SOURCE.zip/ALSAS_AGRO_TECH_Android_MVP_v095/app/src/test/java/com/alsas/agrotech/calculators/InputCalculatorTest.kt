package com.alsas.agrotech.calculators

import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test

class InputCalculatorTest {
    @Test fun fertilizerProductUsesUserEnteredNutrientRateAndGrade() = assertEquals(200.0, InputCalculator.fertilizerProductKg(2.0, 30.0, 30.0), 0.0001)
    @Test fun seedQuantityScalesByArea() = assertEquals(45.0, InputCalculator.seedQuantityKg(1.5, 30.0), 0.0001)
    @Test fun sprayProductUsesLabelRatePerTank() = assertEquals(300.0, InputCalculator.sprayProductMl(6.0, 50.0), 0.0001)
    @Test fun waterVolumeUsesTankCapacity() = assertEquals(90.0, InputCalculator.totalWaterLitres(6.0, 15.0), 0.0001)
    @Test fun rejectsZeroArea() { assertThrows(IllegalArgumentException::class.java) { InputCalculator.seedQuantityKg(0.0, 20.0) } }
    @Test fun rejectsInvalidFertilizerGrade() { assertThrows(IllegalArgumentException::class.java) { InputCalculator.fertilizerProductKg(1.0, 20.0, 0.0) } }
}
