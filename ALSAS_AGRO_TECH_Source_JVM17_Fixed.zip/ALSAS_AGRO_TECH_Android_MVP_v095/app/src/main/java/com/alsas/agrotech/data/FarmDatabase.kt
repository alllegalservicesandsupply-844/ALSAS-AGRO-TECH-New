package com.alsas.agrotech.data

import android.content.Context
import androidx.room.*
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow


@Entity(tableName = "farmer_profile")
data class FarmerProfile(
    @PrimaryKey val id: Int = 1,
    val fullName: String,
    val phone: String,
    val state: String,
    val localGovernment: String,
    val village: String,
    val preferredLanguage: String = "Hausa",
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "farm_records")
data class FarmRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val farmName: String,
    val crop: String,
    val hectares: Double,
    val season: String,
    @ColumnInfo(defaultValue = "''") val state: String = "",
    @ColumnInfo(defaultValue = "''") val localGovernment: String = "",
    @ColumnInfo(defaultValue = "''") val village: String = "",
    @ColumnInfo(defaultValue = "''") val locationNote: String = "",
    @ColumnInfo(defaultValue = "''") val variety: String = "",
    val plantingDateMillis: Long? = null,
    val expectedHarvestMillis: Long? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "ledger",
    indices = [Index("farmId"), Index("dateMillis")]
)
data class LedgerEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val farmId: Long,
    val title: String,
    // Store money as integer kobo to avoid floating-point currency errors.
    val amountKobo: Long,
    // "INCOME" or "EXPENSE"
    val kind: String,
    val category: String = "Other",
    val dateMillis: Long = System.currentTimeMillis(),
    val note: String = ""
)

@Entity(
    tableName = "farm_tasks",
    indices = [Index("farmId"), Index("dueDateMillis")]
)
data class FarmTask(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val farmId: Long,
    val title: String,
    val dueDateMillis: Long,
    val completed: Boolean = false,
    val note: String = ""
)


@Entity(tableName = "harvest_records", indices = [Index("farmId"), Index("harvestDateMillis")])
data class HarvestRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val farmId: Long,
    val cropName: String,
    val harvestDateMillis: Long,
    val quantityKg: Double,
    val bagsCount: Double,
    val bagWeightKg: Double,
    val lossKg: Double,
    val salePricePerBagKobo: Long,
    val notes: String = ""
)


@Entity(tableName = "soil_tests", indices = [Index("farmId"), Index("testDateMillis")])
data class SoilTestRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val farmId: Long,
    val testDateMillis: Long = System.currentTimeMillis(),
    val ph: Double?,
    val nitrogenMgKg: Double?,
    val phosphorusMgKg: Double?,
    val potassiumMgKg: Double?,
    val organicMatterPercent: Double?,
    val texture: String = "Unknown",
    val laboratory: String = "",
    val notes: String = ""
)

@Dao
interface FarmDao {
    @Query("SELECT * FROM farmer_profile WHERE id = 1 LIMIT 1")
    fun farmerProfile(): Flow<FarmerProfile?>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveFarmerProfile(profile: FarmerProfile)

    @Insert suspend fun addFarm(farm: FarmRecord): Long
    @Update suspend fun updateFarm(farm: FarmRecord)
    @Delete suspend fun deleteFarm(farm: FarmRecord)
    @Query("DELETE FROM ledger WHERE farmId = :farmId")
    suspend fun deleteLedgerForFarm(farmId: Long)
    @Query("DELETE FROM farm_tasks WHERE farmId = :farmId")
    suspend fun deleteTasksForFarm(farmId: Long)
    @Query("DELETE FROM harvest_records WHERE farmId = :farmId")
    suspend fun deleteHarvestForFarm(farmId: Long)
    @Query("DELETE FROM soil_tests WHERE farmId = :farmId")
    suspend fun deleteSoilTestsForFarm(farmId: Long)
    @Transaction
    suspend fun deleteFarmAndRelatedData(farm: FarmRecord) {
        deleteLedgerForFarm(farm.id)
        deleteTasksForFarm(farm.id)
        deleteHarvestForFarm(farm.id)
        deleteSoilTestsForFarm(farm.id)
        deleteFarm(farm)
    }
    @Query("SELECT * FROM farm_records ORDER BY createdAt DESC")
    fun farms(): Flow<List<FarmRecord>>

    @Insert suspend fun addLedger(entry: LedgerEntry)
    @Query("SELECT * FROM ledger WHERE farmId = :farmId ORDER BY dateMillis DESC")
    fun ledger(farmId: Long): Flow<List<LedgerEntry>>
    @Query("SELECT COALESCE(SUM(amountKobo),0) FROM ledger WHERE farmId=:farmId AND kind='INCOME'")
    fun incomeKobo(farmId: Long): Flow<Long>
    @Query("SELECT COALESCE(SUM(amountKobo),0) FROM ledger WHERE farmId=:farmId AND kind='EXPENSE'")
    fun expensesKobo(farmId: Long): Flow<Long>

    @Insert suspend fun addHarvest(record: HarvestRecord)
    @Query("SELECT * FROM harvest_records WHERE farmId=:farmId ORDER BY harvestDateMillis DESC")
    fun harvestRecords(farmId: Long): Flow<List<HarvestRecord>>
    @Query("SELECT COALESCE(SUM(quantityKg),0) FROM harvest_records WHERE farmId=:farmId")
    fun totalHarvestKg(farmId: Long): Flow<Double>
    @Query("SELECT COALESCE(SUM(lossKg),0) FROM harvest_records WHERE farmId=:farmId")
    fun totalLossKg(farmId: Long): Flow<Double>

    @Insert suspend fun addSoilTest(test: SoilTestRecord)
    @Query("SELECT * FROM soil_tests WHERE farmId=:farmId ORDER BY testDateMillis DESC")
    fun soilTests(farmId: Long): Flow<List<SoilTestRecord>>

    @Insert suspend fun addTask(task: FarmTask)
    @Query("SELECT * FROM farm_tasks WHERE farmId=:farmId ORDER BY dueDateMillis")
    fun tasks(farmId: Long): Flow<List<FarmTask>>
    @Query("UPDATE farm_tasks SET completed=:completed WHERE id=:taskId")
    suspend fun markTask(taskId: Long, completed: Boolean)
}

@Database(entities = [FarmerProfile::class, FarmRecord::class, LedgerEntry::class, FarmTask::class, HarvestRecord::class, SoilTestRecord::class], version = 8, exportSchema = true)
abstract class FarmDatabase : RoomDatabase() {
    abstract fun farmDao(): FarmDao

    companion object {
        @Volatile private var INSTANCE: FarmDatabase? = null

        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("""CREATE TABLE IF NOT EXISTS ledger_new (
                    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                    farmId INTEGER NOT NULL,
                    title TEXT NOT NULL,
                    amountKobo INTEGER NOT NULL,
                    kind TEXT NOT NULL,
                    category TEXT NOT NULL,
                    dateMillis INTEGER NOT NULL,
                    note TEXT NOT NULL
                )""".trimIndent())
                db.execSQL("""INSERT INTO ledger_new
                    (id, farmId, title, amountKobo, kind, category, dateMillis, note)
                    SELECT id, farmId, title, CAST(ROUND(amountNaira * 100) AS INTEGER),
                    kind, category, dateMillis, note FROM ledger""".trimIndent())
                db.execSQL("DROP TABLE ledger")
                db.execSQL("ALTER TABLE ledger_new RENAME TO ledger")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_ledger_farmId ON ledger(farmId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_ledger_dateMillis ON ledger(dateMillis)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_farm_tasks_farmId ON farm_tasks(farmId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_farm_tasks_dueDateMillis ON farm_tasks(dueDateMillis)")
            }
        }

        private val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("""CREATE TABLE IF NOT EXISTS farm_tasks_new (
                    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                    farmId INTEGER NOT NULL,
                    title TEXT NOT NULL,
                    dueDateMillis INTEGER NOT NULL,
                    completed INTEGER NOT NULL,
                    note TEXT NOT NULL
                )""".trimIndent())
                db.execSQL("""INSERT INTO farm_tasks_new
                    (id, farmId, title, dueDateMillis, completed, note)
                    SELECT id, farmId, title, dueDateMillis, completed, note FROM farm_tasks""".trimIndent())
                db.execSQL("DROP TABLE farm_tasks")
                db.execSQL("ALTER TABLE farm_tasks_new RENAME TO farm_tasks")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_farm_tasks_farmId ON farm_tasks(farmId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_farm_tasks_dueDateMillis ON farm_tasks(dueDateMillis)")
            }
        }

        // v0.3 prototype introduced foreign keys that could reject legacy orphan rows.
        // v0.4 removes those constraints while retaining every ledger/task row.
        private val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("""CREATE TABLE IF NOT EXISTS ledger_v4 (
                    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                    farmId INTEGER NOT NULL,
                    title TEXT NOT NULL,
                    amountKobo INTEGER NOT NULL,
                    kind TEXT NOT NULL,
                    category TEXT NOT NULL,
                    dateMillis INTEGER NOT NULL,
                    note TEXT NOT NULL
                )""".trimIndent())
                db.execSQL("""INSERT INTO ledger_v4
                    (id, farmId, title, amountKobo, kind, category, dateMillis, note)
                    SELECT id, farmId, title, amountKobo, kind, category, dateMillis, note FROM ledger""".trimIndent())
                db.execSQL("DROP TABLE ledger")
                db.execSQL("ALTER TABLE ledger_v4 RENAME TO ledger")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_ledger_farmId ON ledger(farmId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_ledger_dateMillis ON ledger(dateMillis)")

                db.execSQL("""CREATE TABLE IF NOT EXISTS farm_tasks_v4 (
                    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                    farmId INTEGER NOT NULL,
                    title TEXT NOT NULL,
                    dueDateMillis INTEGER NOT NULL,
                    completed INTEGER NOT NULL,
                    note TEXT NOT NULL
                )""".trimIndent())
                db.execSQL("""INSERT INTO farm_tasks_v4
                    (id, farmId, title, dueDateMillis, completed, note)
                    SELECT id, farmId, title, dueDateMillis, completed, note FROM farm_tasks""".trimIndent())
                db.execSQL("DROP TABLE farm_tasks")
                db.execSQL("ALTER TABLE farm_tasks_v4 RENAME TO farm_tasks")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_farm_tasks_farmId ON farm_tasks(farmId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_farm_tasks_dueDateMillis ON farm_tasks(dueDateMillis)")
            }
        }

        private val MIGRATION_4_5 = object : Migration(4, 5) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("""CREATE TABLE IF NOT EXISTS farmer_profile (
                    id INTEGER NOT NULL PRIMARY KEY,
                    fullName TEXT NOT NULL,
                    phone TEXT NOT NULL,
                    state TEXT NOT NULL,
                    localGovernment TEXT NOT NULL,
                    village TEXT NOT NULL,
                    preferredLanguage TEXT NOT NULL,
                    updatedAt INTEGER NOT NULL
                )""".trimIndent())
            }
        }

        private val MIGRATION_5_6 = object : Migration(5, 6) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE farm_records ADD COLUMN state TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE farm_records ADD COLUMN localGovernment TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE farm_records ADD COLUMN village TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE farm_records ADD COLUMN locationNote TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE farm_records ADD COLUMN variety TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE farm_records ADD COLUMN plantingDateMillis INTEGER")
                db.execSQL("ALTER TABLE farm_records ADD COLUMN expectedHarvestMillis INTEGER")
            }
        }

        private val MIGRATION_6_7 = object : Migration(6, 7) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("""CREATE TABLE IF NOT EXISTS harvest_records (
                    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, farmId INTEGER NOT NULL,
                    cropName TEXT NOT NULL, harvestDateMillis INTEGER NOT NULL,
                    quantityKg REAL NOT NULL, bagsCount REAL NOT NULL, bagWeightKg REAL NOT NULL,
                    lossKg REAL NOT NULL, salePricePerBagKobo INTEGER NOT NULL, notes TEXT NOT NULL
                )""".trimIndent())
                db.execSQL("CREATE INDEX IF NOT EXISTS index_harvest_records_farmId ON harvest_records(farmId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_harvest_records_harvestDateMillis ON harvest_records(harvestDateMillis)")
            }
        }

        private val MIGRATION_7_8 = object : Migration(7, 8) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("""CREATE TABLE IF NOT EXISTS soil_tests (
                    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, farmId INTEGER NOT NULL,
                    testDateMillis INTEGER NOT NULL, ph REAL, nitrogenMgKg REAL,
                    phosphorusMgKg REAL, potassiumMgKg REAL, organicMatterPercent REAL,
                    texture TEXT NOT NULL, laboratory TEXT NOT NULL, notes TEXT NOT NULL
                )""".trimIndent())
                db.execSQL("CREATE INDEX IF NOT EXISTS index_soil_tests_farmId ON soil_tests(farmId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_soil_tests_testDateMillis ON soil_tests(testDateMillis)")
            }
        }

        fun get(context: Context): FarmDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(
                context.applicationContext, FarmDatabase::class.java, "alsas_agro_tech.db"
            ).addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4, MIGRATION_4_5, MIGRATION_5_6, MIGRATION_6_7, MIGRATION_7_8).build().also { INSTANCE = it }
        }
    }
}
